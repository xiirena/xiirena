/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from "motion/react";
import { Users, Shield, Code, Hammer, Heart, MessageSquare, ExternalLink, ChevronRight } from "lucide-react";
import { useState } from "react";

const SERVERS = [
  {
    name: "2Bad MC",
    icon: Heart,
    color: "from-purple-400 to-pink-500",
    description: "My primary server which i am one of the founders of, my use towards the server is coding, managing, moderating and way more",
    role: "Founder / Owner",
    status: "Maintenance",
    link: "https://discord.gg/xnrZ4aRg94"
  },
  {
    name: "Purge SMP",
    icon: Shield,
    color: "from-blue-400 to-cyan-500",
    description: "A vanilla private smp server homed to over 200 players, which i co own",
    role: "Co Owner",
    status: "Active",
    link: "#"
  },
  {
    name: "Trimz",
    icon: Code,
    color: "from-indigo-400 to-purple-500",
    description: "A custom kit server with powerful trimable swords.",
    role: "Moderator",
    status: "Active",
    link: "https://discord.gg/6z9Jk2G9rv"
  }
];

function Background() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-[#050208]">
      <motion.div
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute -top-[20%] -left-[10%] h-[70%] w-[70%] rounded-full bg-purple-900/20 blur-[120px]"
      />
      <motion.div
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2,
        }}
        className="absolute -bottom-[10%] -right-[10%] h-[60%] w-[60%] rounded-full bg-indigo-900/20 blur-[100px]"
      />
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.03] pointer-events-none" />
    </div>
  );
}

interface ServerData {
  name: string;
  icon: any;
  color: string;
  description: string;
  role: string;
  status: string;
  link: string;
}

interface ServerCardProps {
  server: ServerData;
  index: number;
  key?: string;
}

function ServerCard({ server, index }: ServerCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -5 }}
      className="glass group relative overflow-hidden rounded-2xl p-6 transition-all duration-300 hover-glow"
    >
      <div className={`absolute top-0 right-0 h-24 w-24 translate-x-8 -translate-y-8 rounded-full bg-gradient-to-br ${server.color} opacity-10 blur-2xl transition-opacity group-hover:opacity-20`} />
      
      <div className="relative z-10">
        <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${server.color} p-3 shadow-lg`}>
          <server.icon className="h-full w-full text-white" />
        </div>
        
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-display text-xl font-bold tracking-tight">{server.name}</h3>
          <span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-full border ${
            server.status === 'Active' ? 'border-green-500/50 text-green-400 bg-green-500/10' : 
            'border-white/20 text-white/40 bg-white/5'
          }`}>
            {server.status}
          </span>
        </div>
        
        <div className="mb-4">
          <span className="text-xs font-medium text-purple-400 uppercase tracking-wider">{server.role}</span>
        </div>

        <p className="mb-6 text-sm text-white/60 leading-relaxed">
          {server.description}
        </p>
        
        <motion.a
          href={server.link}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex w-full items-center justify-center rounded-xl bg-white/10 py-3 text-sm font-semibold transition-colors hover:bg-white/20"
        >
          Visit Server
          <ExternalLink className="ml-2 h-4 w-4" />
        </motion.a>
      </div>
    </motion.div>
  );
}

const HIGHLIGHTS = [
  { 
    title: "My skills", 
    bio: "I started moderating on servers about 3 years back when i would usually be helper on some servers, throught the time i would learn more stuff like coding, plugin management and more right know i am currently staff in a few servers that are decently big and i vring a lot to the table." 
  },
  { 
    title: "What i offer", 
    bio: "When i get accepted to a server as a staff i look towards giving them my personal best, i offer a non-lying personality, honest style and bring my skills with me, plugin management, game knowledge, coding, networking and my trustworthy identitiy." 
  },
  { 
    title: "How to contanct me", 
    bio: "You can contact me by messaging me on discord privately 'xiirena', i will work good as a staff member and do my best to adapt to your community and will improve as time goes by (i can code custom stuff for $ or sometimes for free <3)" 
  }
];

interface HighlightBoxProps {
  title: string;
  bio: string;
  index: number;
  key?: string;
}

function HighlightBox({ title, bio, index }: HighlightBoxProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      className="glass group relative overflow-hidden rounded-2xl p-8 transition-all duration-500 hover-glow"
    >
      {/* Interval Glow Effect */}
      <motion.div
        animate={{
          opacity: [0.05, 0.2, 0.05],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
          delay: index * 0.5,
        }}
        className="absolute inset-0 bg-purple-500/10 blur-3xl"
      />
      
      <div className="relative z-10">
        <div className="mb-4 h-1 w-12 rounded-full bg-purple-500/50" />
        <h4 className="font-display mb-4 text-2xl font-bold tracking-tight text-white">
          {title}
        </h4>
        <p className="text-base text-white/60 leading-relaxed font-light">
          {bio}
        </p>
      </div>
    </motion.div>
  );
}

export default function App() {
  const [isLoaded, setIsLoaded] = useState(false);

  return (
    <div className="relative min-h-screen selection:bg-purple-500/30">
      <Background />
      
      {/* Navigation */}
      <nav className="fixed top-0 z-50 w-full border-b border-white/5 bg-[#050208]/50 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-purple-500 to-indigo-600" />
            <span className="font-display text-xl font-bold tracking-tighter">XIIRENA</span>
          </motion.div>
          
          <div className="hidden items-center gap-8 md:flex">
            {['Home', 'Positions', 'About', 'Discord'].map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} className="text-sm font-medium text-white/60 transition-colors hover:text-white">
                {item}
              </a>
            ))}
          </div>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="rounded-full bg-white px-5 py-2 text-sm font-bold text-black hover-glow"
          >
            Contact Me
          </motion.button>
        </div>
      </nav>

      <main className="mx-auto max-w-7xl px-6 pt-32 pb-24">
        {/* Hero Section */}
        <section id="home" className="mb-32 flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative mb-8"
          >
            <div className="absolute inset-0 animate-pulse rounded-full bg-purple-500/20 blur-3xl" />
            <motion.div
              animate={{ 
                y: [0, -10, 0],
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
            >
              <img
                src="https://cdn.discordapp.com/attachments/1490432988389970093/1491192483252670555/2025-06-26_cats_baby_face_hero.png?ex=69d6ccb9&is=69d57b39&hm=81e6027563e09675028dac621b338cc53a2f8799bb113df9a31d9d46d96b02f7&"
                alt="Xiirena Profile"
                referrerPolicy="no-referrer"
                className="relative h-40 w-40 rounded-full border-4 border-purple-500/30 object-cover shadow-2xl"
                onLoad={() => setIsLoaded(true)}
              />
            </motion.div>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute -inset-4 rounded-full border-2 border-dashed border-purple-500/20"
            />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="font-display mb-4 text-6xl font-black tracking-tighter md:text-8xl"
          >
            <motion.span 
              animate={{ 
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
              }}
              transition={{ 
                duration: 5, 
                repeat: Infinity, 
                ease: "linear" 
              }}
              className="bg-gradient-to-r from-white via-purple-400 to-white bg-[length:200%_auto] bg-clip-text text-transparent"
            >
              XIIRENA
            </motion.span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-12 max-w-2xl text-lg text-white/60 leading-relaxed md:text-xl"
          >
            Passionate Minecraft server manager/developer skills i've held throughout my journey.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-wrap justify-center gap-4"
          >
            <a href="#positions" className="rounded-full bg-purple-600 px-8 py-4 text-lg font-bold transition-all hover:bg-purple-500 hover-glow">
              My Experience
            </a>
            <a href="#discord" className="flex items-center gap-2 rounded-full bg-white/5 px-8 py-4 text-lg font-bold backdrop-blur-md transition-all hover:bg-white/10">
              <MessageSquare className="h-5 w-5" />
              Contact Me
            </a>
          </motion.div>
        </section>

        {/* Highlights Section */}
        <section id="about" className="mb-32">
          <div className="mb-16 text-center">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="font-display mb-4 text-4xl font-bold tracking-tight md:text-5xl"
            >
              My Journey
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-white/40"
            >
              A look into my background and what I bring to every project.
            </motion.p>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {HIGHLIGHTS.map((item, index) => (
              <HighlightBox key={item.title} title={item.title} bio={item.bio} index={index} />
            ))}
          </div>
        </section>

        {/* Servers Section */}
        <section id="positions" className="mb-32">
          <div className="mb-16 text-center">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="font-display mb-4 text-4xl font-bold tracking-tight md:text-5xl"
            >
              Servers i work on
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-white/40"
            >
              A collection of communities I've helped build and manage.
            </motion.p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {SERVERS.map((server, index) => (
              <ServerCard key={server.name} server={server} index={index} />
            ))}
          </div>
        </section>

        {/* Footer / Contact */}
        <footer id="discord" className="border-t border-white/5 pt-24 pb-12">
          <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
            <div>
              <div className="mb-4 flex items-center gap-2">
                <div className="h-6 w-6 rounded bg-gradient-to-br from-purple-500 to-indigo-600" />
                <span className="font-display text-lg font-bold tracking-tighter">XIIRENA</span>
              </div>
              <p className="text-sm text-white/40">© 2026 Xiirena Network. All rights reserved.</p>
            </div>
            
            <div className="flex gap-6">
              <a href="#" className="text-white/60 transition-colors hover:text-white">
                <MessageSquare className="h-6 w-6" />
              </a>
              <a href="#" className="text-white/60 transition-colors hover:text-white">
                <Users className="h-6 w-6" />
              </a>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
