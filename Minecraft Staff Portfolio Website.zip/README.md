
  # Minecraft Staff Portfolio Website

  This is a code bundle for Minecraft Staff Portfolio Website. The original project is available at https://www.figma.com/design/gokzYgG7XTYMjhBA8m3lfl/Minecraft-Staff-Portfolio-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  